using Newtonsoft.Json;
using System.IO;
using TMPro;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class 画廊系统 : MonoBehaviour
{
    public GameObject hualang;
    public Button[] hualangbuttons;
    public Button hualangout;
    public Button hualangnext;
    public Button hualangon;
    

    private int hualangindex = 0;
    private readonly int hualangint = 6;
    private readonly int hualangmax = 18;
    public bool hualangload = false;
    public static 画廊系统 Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        hualangout.onClick.AddListener(退出画廊);
        hualangnext.onClick.AddListener(画廊下一页);
        hualangon.onClick.AddListener(画廊上一页);
        hualang.SetActive(false);
    }
    
    private void 退出画廊()
    {
        hualang.SetActive(false);
        初始界面.Instance.menuPane1.SetActive(true);
    }
    private void 画廊下一页()
    {
        if ((hualangindex + 1) * hualangint < hualangmax)
        {
            hualangindex++;
            UpdateUI();
        }
    }
    private void 画廊上一页()
    {
        if (hualangindex > 0)
        {
            hualangindex--;
            UpdateUI();
        }
    }
    public void Showhualang()
    {
        UpdateUI();
        hualang.SetActive(true);
        
    }
    private void UpdateUI()
    {
        for (int i = 0; i < hualangint; i++)
        {
            int slotIndex = hualangint * hualangindex + i;//当前页的索引
            if (slotIndex < hualangmax)
            {
                更新按钮(hualangbuttons[i], slotIndex);//更新按钮
                截图加载(hualangbuttons[i], slotIndex);//加载故事线截图
            }
            else
            {
                hualangbuttons[i].gameObject.SetActive(false);
            }
        }
    }
    private void 更新按钮(Button button, int index)
    {
        // 检查 button 是否为 null,能
        if (button == null)
        {
            Debug.LogError("Button is null");
            return;
        }
        else
        {
            button.gameObject.SetActive(true);//按钮设为可见
            button.interactable = true;//按钮设为可点击

            var savePath = hualanglujin(index);//根据索引生成路径
            var fileExists = File.Exists(savePath);//判断文件是否存在

            if (!fileExists)//如果文件不存在
            {
                button.interactable = false;//按钮设为不可点击
            }
        }
        RawImage rawImageComponent = button.GetComponentInChildren<RawImage>();
        if (rawImageComponent == null)
        {
            Debug.LogError("RawImage component not found on the button or its children.");///
            return;
        }
        rawImageComponent.texture = null;
        



        var textComponents = button.GetComponentsInChildren<TextMeshProUGUI>();//获取子组件
        textComponents[0].text = null;//清空文本，这里显示故事

        button.onClick.RemoveAllListeners();//移除监听器/事件
        button.onClick.AddListener(() => OnButtonClick(button, index));//添加新的监听器

    }
    private void OnButtonClick(Button button, int indexs)
    {
        hualangload= true;
        hualang.SetActive(false);
        VNmang.Instance.Loadhualang(indexs);
    }
    private void 截图加载(Button button, int index)
    {
        var savePath = hualanglujin(index);//根据索引生成路径
        if (File.Exists(savePath))//如果有存档
        {
            // 确保路径中包含正确的文件扩展名
            string imagePath = Path.Combine(Constants.BACKGROUND_PATH, index.ToString());

            // 尝试加载 Texture 资源
            Texture2D texture = Resources.Load<Texture2D>(imagePath);
            if (texture == null)
            {
                Debug.LogError($"没找到图片: {imagePath}");////
                return;
            }

            // 获取 RawImage 组件并设置其纹理
            //Image image = button.GetComponentInChildren<Image>();
            button.GetComponentInChildren<RawImage>().texture = texture;

            //image.sprite = sprite;


            var textComponents = button.GetComponentsInChildren<TextMeshProUGUI>();
            textComponents[0].text = index.ToString();

        }
    }

    private string hualanglujin(int index)
    {
        return Path.Combine(Application.persistentDataPath, Constants.SAVE_FILE_PATH, index+"hualang" + Constants.SAVE_FILE_EXTENSION);
    }

}
