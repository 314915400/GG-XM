using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;
public class 设置 : MonoBehaviour
{
    public GameObject settingPanel;
    public Toggle 全屏开关;//全屏开关
    public Text toggleLabel;//开关内容
    public TMP_Dropdown 下拉;

    private Resolution[] availableResolutions;//可用分辨率数组
    private Resolution defaultResolution;//默认分辨率
    public Button defaultButton;//恢复默认分辨率
    public Button closeButton;//关闭

    public static 设置 Instance {  get; private set; }
    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    void Start()
    {
        初始分辨率();
        全屏开关.isOn = Screen.fullScreenMode == FullScreenMode.FullScreenWindow;//是否全屏
        UpdateToggleLabel(全屏开关.isOn);//更新开关内容为真或假

        全屏开关.onValueChanged.AddListener(SetDisplayMode);//值变化监听
        下拉.onValueChanged.AddListener(SetResolution);
        defaultButton.onClick.AddListener(恢复默认设置);
        closeButton.onClick.AddListener(退出设置);

        settingPanel.SetActive(false);
    }

    public void 显示设置()
    {
        settingPanel.SetActive(true);
    }
    void 初始分辨率()
    {
        availableResolutions = Screen.resolutions;//获取可用分辨率
        下拉.ClearOptions();

        var resolutionMap = new Dictionary<string, Resolution>();
        int currentResolutionIndex = 0;

        foreach (var res in availableResolutions)//遍历可用分辨率
        {
            const float aspectRatio = 16f / 9f;
            const float epsilon = 0.01f;//允许的误差

            if(Mathf.Abs((float)res.width / res.height - aspectRatio) > epsilon)//如果不是16:9
            {
                continue;//跳过
            }
            string option = res.width + "::" + res.height;
            if(!resolutionMap.ContainsKey(option))//看看有没有存过，去重
            {
                resolutionMap[option]= res;//存
                下拉.options.Add(new TMP_Dropdown.OptionData(option));//添加选项
                if(res.width == Screen.currentResolution.width && res.height == Screen.currentResolution.height)//看看是不是当前分辨率
                {
                    currentResolutionIndex = 下拉.options.Count - 1;//设为当前分辨率
                    defaultResolution = res;//设为默认分辨率
                }
            }
        }
        下拉.value = currentResolutionIndex;//设置当前分辨率
        下拉.RefreshShownValue();//刷新显示值
    }
    void SetDisplayMode(bool isFullScreen)//设置显示模式
    {
        Screen.fullScreenMode = isFullScreen ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;//如果是全屏就是全屏，不是就不是
        UpdateToggleLabel(isFullScreen);//更新开关内容为真或假
    }

    void UpdateToggleLabel(bool isFullScreen)
    {
        toggleLabel.text = isFullScreen ? "Fullscreen" : "Windowed";//全屏，窗口
    }

    void SetResolution(int index)
    {
        string[] dimensions = 下拉.options[index].text.Split("::");
        int width = int.Parse(dimensions[0].Trim());
        int height = int.Parse(dimensions[1].Trim());
        Screen.SetResolution(width, height, Screen.fullScreenMode);
    }

    public void 退出设置()
    {
        settingPanel.SetActive(false);
    }

    void 恢复默认设置()
    {
        下拉.value = 下拉.options.FindIndex(
            option => option.text == $"{defaultResolution.width}x{defaultResolution.height}");
        全屏开关.isOn = true;
    }
}
