using DG.Tweening;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class VNmang : MonoBehaviour
{
    #region ����
    public GameObject gamePane1;
    public GameObject dialogueBox;
    public TextMeshProUGUI speakerName;
    public TypewriterEffect typewriterEffect;
    public ��Ļ������ screenShotter;

    public Image avatarImage;
    public AudioSource vocalAudio;
    public Image backgroundImage;
    public AudioSource backgroundMusic;
    public Image characterImage1;
    public Image characterImage2;


    public GameObject choicePane1;
    public Button choiceButton1;
    public Button choiceButton2;

    public GameObject bottomButtons;
    public Button autoButton;
    public Button skipButton;
    public Button saveButton;
    public Button loadButton;
    public Button historyButton;
    public Button settingsButton;
    public Button homeButton;
    public Button closeButton;


    private readonly string storyPath = Constants.STORY_PATH;
    private readonly string defaultStoryFileName = Constants.DEFAULT_STORY_FILE_NAME;
    private readonly int defaultStartLine = Constants.DEFAULT_START_LINE;
    private readonly string excelFileExtension = Constants.EXCEL_FILE_EXTENSION;

    private string �����ļ�·��;//�����ļ�·��
    private byte[] screenshotData;//��ͼ
    private string currentSpeakingContent;//��ǰ������

    private List<ExcelReader.ExcelData> storyData;
    private int currentLine;
    private string currentStoryFileName;
    private float currentTypingSpeed = Constants.DEFAULT_TYPING_SPEED;


    private bool isAutoPlay = false;
    private bool isSkip = false;
    private bool isLoad = false;
    private int maxReachedLineIndex = 0;
    private Dictionary<string, int> globalMaxReachedLineIndices = new Dictionary<string, int>();//ȫ�ִ洢ÿ���ļ�����Զ�������ֵ�
    private LinkedList<string> historyRecords = new LinkedList<string>();//��ʷ��¼

    public static VNmang Instance { get; private set;}
    #endregion
    #region ��������
    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);//���ٵ�ǰ��Ϸ����
        }
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        InitializeSaveFilePath();//��ʼ�������ļ�·��
        bottomButtonsAddListener();
        //gamePane1.SetActive(false);//��ʼ����ʾ��Ϸ����
    }

    // Update is called once per frame
    void Update()
    {
        if(!��ʼ����.Instance.menuPane1.activeSelf &&
           !SaveLoad.Instance.saveLoadPane1.activeSelf &&
           !��ʷ��¼.Instance.historyScrollView.activeSelf &&
           !����.Instance.settingPanel.activeSelf &&
           !����ϵͳ.Instance.hualang.activeSelf  &&
        gamePane1.activeSelf)
        {
            if(Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
            { 
                if(!dialogueBox.activeSelf)//�Ի���
                {
                      OpenUI();//��ʾUI
                }
                else if (!IsHittingBottomButtons())//�ײ���ť
                {
                      DisplayNextLine();
                }

            }
            if(Input.GetKeyDown(KeyCode.Escape))
            {
                if(dialogueBox.activeSelf)
                {
                    CloseUI();
                }
                else
                {
                    OpenUI();
                }
            }
            if(Input.GetKeyDown(KeyCode.LeftControl) || Input.GetKeyDown(KeyCode.RightControl))
            {
                Debug.Log("����CTRL��");
                CtrlSkip();
            }
        }
    }
    #endregion
    #region ��ʼ��
    void InitializeSaveFilePath()
    {
        �����ļ�·�� = Path.Combine(Application.persistentDataPath,Constants.SAVE_FILE_PATH);
        if (!Directory.Exists(�����ļ�·��))
        {
            Directory.CreateDirectory(�����ļ�·��);//����Ŀ¼
        }
    }
    void bottomButtonsAddListener()
    {
        autoButton.onClick.AddListener(OnAutoButtonClick);
        skipButton.onClick.AddListener(OnSkipButtonClick);
        saveButton.onClick.AddListener(OnSaveButtonClick);
        loadButton.onClick.AddListener(OnLoadButtonClick);
        historyButton.onClick.AddListener(OnHistoryButtonClick);
        settingsButton.onClick.AddListener(OnSettingButtonClick);
        homeButton.onClick.AddListener(OnHomeButtonClick);
        closeButton.onClick.AddListener(OnCloseButtonClick);
    }
    public void StartGame()
    {
        InitializeAndLoadStory(defaultStoryFileName,defaultStartLine);
    }
    void InitializeAndLoadStory(string fileName,int lineNumber)
    {
        Initialize(lineNumber);//��ʼ�����ر�UI
        LoadStoryFromFile(fileName);
        if(isLoad)
        {
            �ָ�();
            isLoad = false;
        }
        DisplayNextLine();
    }
    void Initialize(int line)
    {
        currentLine =line;

        backgroundImage.gameObject.SetActive(false);
        backgroundMusic.gameObject.SetActive(false);

        avatarImage.gameObject.SetActive(false);
        vocalAudio.gameObject.SetActive(false);

        characterImage1.gameObject.SetActive(false);
        characterImage2.gameObject.SetActive(false);

        choicePane1.SetActive(false);
    }


    void LoadStoryFromFile(string fileName)
    {
        currentStoryFileName = fileName;
        var path = storyPath + fileName + excelFileExtension;
        storyData = ExcelReader.ReadExcel(path);
        if (storyData == null || storyData.Count == 0)
        {
            Debug.LogError(Constants.NO_DATA_FOUND);
        }
        if(globalMaxReachedLineIndices.ContainsKey(currentStoryFileName))
        {
            maxReachedLineIndex = globalMaxReachedLineIndices[currentStoryFileName];//��ȡȡ��Զ����
        }
        else
        {
            maxReachedLineIndex = 0;
            globalMaxReachedLineIndices[currentStoryFileName] = maxReachedLineIndex;
        }
    }
    #endregion
    #region չʾ
    void DisplayNextLine()
    {
        if(currentLine > maxReachedLineIndex)
        {
            maxReachedLineIndex = currentLine;
            globalMaxReachedLineIndices[currentStoryFileName] = maxReachedLineIndex;//������Զ����
        }
        if (currentLine >= storyData.Count-1)//����Ƿ��Ѿ�����
        {
            if(isAutoPlay)//ֹͣ�Զ�����
            {
                isAutoPlay = false;
                UpdateButtonImage(Constants.AUTO_OFF, autoButton);//���°�ťͼƬ
            }
            if (storyData[currentLine].speakerName == Constants.END_OF_STORY)
            {
                Debug.Log(Constants.END_OF_STORY);//����
            }
            if (storyData[currentLine].speakerName == Constants.CHOICE)
            {
                ShowChoices();   //��ʾѡ����
            }
            return;
        }
        if (typewriterEffect.IsTyping())//����Ƿ����ڴ���
        {
            typewriterEffect.CompleteLine();//��������
        }
        else
        {
            DisplayThisLine();//��ʾ��ǰ������
        }
    }
    void DisplayThisLine()
    {
        var data = storyData[currentLine];//var���������ж�����
        speakerName.text = data.speakerName;
        currentSpeakingContent = data.speakingContent;//�޸ĵ�ǰ������
        typewriterEffect.StartTyping(currentSpeakingContent,currentTypingSpeed);//��ʼ����

        RecordHistory(speakerName.text, currentSpeakingContent);
        if (NotNullNorEmpty(data.avatarImageFileName))
        {
            UpdateAvatarImage(data.avatarImageFileName);//����ͷ��
        }
        else
        {
            avatarImage.gameObject.SetActive(false);//����ͷ��
        }
        if(NotNullNorEmpty(data.vocalAudioFileName))
        {
            PlayVocalAudio(data.vocalAudioFileName);//��������
        }
        if (NotNullNorEmpty(data.backgroundImageFileName))
        {
            UpdateBackgroundImage(data.backgroundImageFileName);//���±���
        }
        if (NotNullNorEmpty(data.backgroundMusicFileName))
        {
            PlayBackgroundMusic(data.backgroundMusicFileName);//���ű�������
        }
        if (NotNullNorEmpty(data.character1Action))
        {
            UpdateCharacterImage(data.character1Action, data.character1ImageFileName,
                                 characterImage1,data.coordinateX1);//���½�ɫ1�Ͷ���
        }
        if (NotNullNorEmpty(data.character2Action))
        {
            UpdateCharacterImage(data.character2Action, data.character2ImageFileName,
                                 characterImage2,data.coordinateX2);//���½�ɫ2�Ͷ���
        }
        if (NotNullNorEmpty(data.hualangjihao))
        {
            if(data.hualangjihao=="end" && ����ϵͳ.Instance.hualangload )
            {
                ����ϵͳ.Instance.hualangload = false;
                gamePane1.SetActive(false);
                ����ϵͳ.Instance.Showhualang();
            }
            else
            {
                �Զ����滭��(data.hualangjihao);
            }
        }
        currentLine++;//������һ
        
    }

    void RecordHistory(string speaker, string content)
    {
        string history = speaker + Constants.COLON + content;
        if (historyRecords.Count >=Constants.MAX_LENGTH)
        {
            historyRecords.RemoveFirst();//ɾ��ͷ��
        }
        historyRecords.AddLast(history);//����ĩβ
    }
    void �ָ�()
    {
        var data = storyData[currentLine];
        if (NotNullNorEmpty(data.�ϴα���))
        {
            UpdateBackgroundImage(data.�ϴα���);
        }
        if(NotNullNorEmpty(data.�ϴ�����))
        {
            PlayBackgroundMusic(data.�ϴ�����);
        }
        if(data.character1Action!= Constants.APPEAR_AT
            && NotNullNorEmpty(data.character1ImageFileName))
        {
            UpdateCharacterImage(Constants.APPEAR_AT, data.character1ImageFileName,
                                 characterImage1,data.�ϴ�λ��1);
        }
        if(data.character2Action!= Constants.APPEAR_AT
            && NotNullNorEmpty(data.character2ImageFileName))
        {
            UpdateCharacterImage(Constants.APPEAR_AT, data.character2ImageFileName,
                                 characterImage2,data.�ϴ�λ��2);
        }
    }
    bool NotNullNorEmpty(string str)//�ж��Ƿ�Ϊ��
    {
        return !string.IsNullOrEmpty(str);
    }
    #endregion
    #region ѡ����
    void ShowChoices()//��ʾѡ����
    {
        var data = storyData[currentLine];
        choiceButton1.onClick.RemoveAllListeners();
        choiceButton2.onClick.RemoveAllListeners();
        choicePane1.SetActive(true);//��ʾѡ����
        choiceButton1.GetComponentInChildren<TextMeshProUGUI>().text = data.speakingContent;//����ѡ��������
        choiceButton1.onClick.AddListener(() => InitializeAndLoadStory(data.avatarImageFileName,defaultStartLine));
        choiceButton2.GetComponentInChildren<TextMeshProUGUI>().text = data.vocalAudioFileName;
        choiceButton2.onClick.AddListener(() => InitializeAndLoadStory(data.backgroundImageFileName, defaultStartLine));
    }
    #endregion
    #region ��Ƶ ͼƬ ����
    void UpdateAvatarImage(string imageFileName)//����ͷ��
    {
        var imagePath = Constants.AVATAR_PATH + imageFileName;
        UpdateImage(imagePath, avatarImage);
    }

    void PlayVocalAudio(string audioFileName)//��������
    {
        string audioPath = Constants.VOCAL_PATH + audioFileName;
        PlayAudio(audioPath, vocalAudio, false);
    }

    void UpdateBackgroundImage(string imageFileName)//���±���
    {
        string imagePath = Constants.BACKGROUND_PATH + imageFileName;
        UpdateImage(imagePath, backgroundImage);
    }
    void PlayBackgroundMusic(string musicFileName)//���ű�������
    {
        string musicPath = Constants.MUSIC_PATH+ musicFileName;
        PlayAudio(musicPath, backgroundMusic, true);
    }
    void UpdateCharacterImage(string action, string imageFileName, Image characterImage,string x)
    {
        //����actionִ�ж�Ӧ�Ķ��������
        if (action.StartsWith(Constants.APPEAR_AT))//����appearat(x,y)��������(x,y)��ʾ��ɫ����
        {
            string imagePath = Constants.CHARACTER_PATH + imageFileName;//��ɫ����·��
            if(NotNullNorEmpty(x))
            {
                UpdateImage(imagePath, characterImage);//��ʾ����
                var newPosition = new Vector2(float.Parse(x), characterImage.rectTransform.anchoredPosition.y);//��ɫ������λ��
                characterImage.rectTransform.anchoredPosition = newPosition;//����λ��
                characterImage.DOFade(1, (isLoad ? 0 : Constants.DURATION_TIME)).From(0);//����ɫ����0-1
            }
            else
            {
                Debug.LogError(Constants.COORDINATE_MISSING);
            }
        }
        else if (action == Constants.DISAPPEAR)//disappear�������ؽ�ɫ����
        {
            characterImage.DOFade(0,Constants.DURATION_TIME).OnComplete(() => characterImage.gameObject.SetActive(false));//������ɫ��Ȼ����Ϊ�ǻ״̬
        }
        else if (action.StartsWith(Constants.MOVE_TO))//����move to(x,y)�������ƶ���ɫ���浽(x,y)
        {
            if (NotNullNorEmpty(x))
            {
                characterImage.rectTransform.DOAnchorPosX(float.Parse(x), Constants.DURATION_TIME);//�ƶ���ɫ�����x��λ��
            }
            else
            {
                Debug.LogError(Constants.COORDINATE_MISSING);
            }

            
        }
    }
    void UpdateImage(string imagePath, Image image)
    {
        Sprite sprite = Resources.Load<Sprite>(imagePath);
        if (sprite != null)
        {
            image.sprite = sprite;
            image.gameObject.SetActive(true);
        }
        else
        {
            Debug.LogError(Constants.IMAGE_LOAD_FAILED + imagePath);
        }
    }
    void PlayAudio(string audioPath, AudioSource audioSource,bool isLoop)
    {
        AudioClip audioClip = Resources.Load<AudioClip>(audioPath);
        if (audioClip != null)
        { 
            audioSource.clip = audioClip;
            audioSource.gameObject.SetActive(true);
            audioSource.Play();
            audioSource.loop = isLoop;//�Ƿ�ѭ������
        }
        else
        {
            Debug.LogError(Constants.AUDIO_LOAD_FAILED + audioPath);
        }
    }
    #endregion
    #region ��ť  
    #region �ײ���ť���
    bool IsHittingBottomButtons()
    {
        return RectTransformUtility.RectangleContainsScreenPoint(
            bottomButtons.GetComponent<RectTransform>(),
            Input.mousePosition,
            Camera.main//֮ǰ��Noll
        );//�ж�����Ƿ��ڵײ���ť�ϣ����������������鷳
    }
    #endregion
    #region �Զ���ť
    void OnAutoButtonClick()
    {
        isAutoPlay = !isAutoPlay;
        UpdateButtonImage((isAutoPlay ? Constants.AUTO_ON : Constants.AUTO_OFF),autoButton);//���°�ťͼƬ
        if (isAutoPlay)
        {
            StartCoroutine(StartAutoPlay());
        }
    }
    private IEnumerator StartAutoPlay()
    {
        while (isAutoPlay)
        {
            if (!typewriterEffect.IsTyping())
            {
                DisplayNextLine();
            }
            yield return new WaitForSeconds(Constants.DEFAULT_AUTO_WAITING_SECONDS);
        }
    }
    void OnSkipButtonClick()
    {
        if(!isSkip && ���Կ��ٲ���())
        {
            StartSkip();
        }
        else if (isSkip)
        {
            StopCoroutine(SkipToMaxReachedLine());//ֹͣ��ΪSkipToMaxReachedLine��Э��
            EndSkip();
        }
    }
  
    bool ���Կ��ٲ���()
    {
        return currentLine <= maxReachedLineIndex;
    }
    void StartSkip()
    {
        isSkip = true;
        UpdateButtonImage(Constants.SKIP_ON, skipButton);
        currentTypingSpeed = Constants.SKIP_MODE_TYPING_SPEED;//��������ٶ�
        StartCoroutine(SkipToMaxReachedLine());
    }
    void UpdateButtonImage(string imageFileName, Button button)
    {
        string imagePath = Constants.BUTTON_PATH + imageFileName;
        UpdateImage(imagePath,button.image);
    }
    
    private IEnumerator SkipToMaxReachedLine()
    {
        while(isSkip)
        {
            if(���Կ��ٲ���())
            {
                DisplayNextLine();
            }
            else
            {
                EndSkip();
            }
            yield return new WaitForSeconds(Constants.DEFAULT_AUTO_WAITING_SECONDS);
        }
    }
    void EndSkip()
    {
        isSkip = false;
        currentTypingSpeed = Constants.DEFAULT_TYPING_SPEED;
        UpdateButtonImage(Constants.SKIP_OFF, skipButton);
    }
    void CtrlSkip()
    {
        currentTypingSpeed = Constants.SKIP_MODE_TYPING_SPEED;
        StartCoroutine(SkipWhilePressingCtrl());
    }
    private IEnumerator SkipWhilePressingCtrl()
    {
        while(Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))
        {
            DisplayNextLine();
            yield return new WaitForSeconds(Constants.DEFAULT_SKIP_WAITING_SECONDS);
        }
    }

    #endregion
    #region ����


    void �Զ����滭��(string indexhualang)
    { 
        SaveGame2(indexhualang);//���滭��
    }
    void OnSaveButtonClick()
    {
        CloseUI();
        Texture2D screenshot = screenShotter.CaptureScreenshot();//��ͼ
        screenshotData = screenshot.EncodeToPNG();//����ͼ����ΪPNG��ʽ
        SaveLoad.Instance.ShowSavePane1(SaveGame);//��ʾ������壬��������Ϊ��������ȥ��Ϊ���ڵ����λʱִ�з���
        OpenUI();
    }
    void SaveGame(int slotIndex)//�浵����
    {
        var saveData = new SaveData
        {
            savedStoryFileName = currentStoryFileName,
            savedLine = currentLine,
            savedSpeakingContent = currentSpeakingContent,//��ǰ���ڴ��ֵ�����
            savedScreenshotData = screenshotData,//��ͼ����
            savedHistoryRecords = historyRecords
        };
        string savePath = Path.Combine(�����ļ�·��, slotIndex + Constants.SAVE_FILE_EXTENSION);//�����ļ�
        string json = JsonConvert.SerializeObject(saveData,Formatting.Indented);//���������л�ΪJSON�ַ���
        File.WriteAllText(savePath, json);//��JSON�ַ���д���ļ�
    }
    void SaveGame2(string slotIndex)//�浵����
    {
        var saveData = new SaveData
        {
            savedStoryFileName = currentStoryFileName,
            savedLine = currentLine,
            savedSpeakingContent = currentSpeakingContent,//��ǰ���ڴ��ֵ�����
        };
        string savePath = Path.Combine(�����ļ�·��, slotIndex+ "hualang" + Constants.SAVE_FILE_EXTENSION);//�����ļ�
        string json = JsonConvert.SerializeObject(saveData, Formatting.Indented);//���������л�ΪJSON�ַ���
        File.WriteAllText(savePath, json);//��JSON�ַ���д���ļ�
    }
    public class SaveData
    {
        public string savedStoryFileName;
        public int savedLine;
        public string savedSpeakingContent;
        public byte[] savedScreenshotData;//��ͼ
        public LinkedList<string> savedHistoryRecords;
    }
    #endregion
    #region ��ȡ
    public void Loadhualang(int slotIndex)
    {
        gamePane1.SetActive(true);
        isLoad = true;
        string savePath = Path.Combine(�����ļ�·��, slotIndex +"hualang"+ Constants.SAVE_FILE_EXTENSION);
        if (File.Exists(savePath))
        {
            string json = File.ReadAllText(savePath);
            var saveData = JsonConvert.DeserializeObject<SaveData>(json);
            
            var lineNumber = saveData.savedLine;
            InitializeAndLoadStory(saveData.savedStoryFileName, lineNumber);
        }
    }
    void OnLoadButtonClick()
    {

        ShowLoadPane1(null);
    }
    public void ShowLoadPane1(Action action)
    {
        SaveLoad.Instance.ShowLoadPane1(LoadGame,action);
    }
    void LoadGame(int slotIndex)
    {
        string savePath = Path.Combine(�����ļ�·��, slotIndex + Constants.SAVE_FILE_EXTENSION);
        if(File.Exists(savePath))
        {
            isLoad = true;
            string json = File.ReadAllText(savePath);
            var saveData = JsonConvert.DeserializeObject<SaveData>(json);
            historyRecords = saveData.savedHistoryRecords;
            historyRecords.RemoveLast();//�Ƴ����һ��Ԫ��
            var lineNumber = saveData.savedLine - 1;
            InitializeAndLoadStory(saveData.savedStoryFileName, lineNumber);
        }
    }
    #endregion
    #region ������ť
    void OnSettingButtonClick()
    {
        ����.Instance.��ʾ����();
    }

    void OnHistoryButtonClick()
    {
        ��ʷ��¼.Instance.ShowHistory(historyRecords);
    }

    void OnHomeButtonClick()//����������
    {
        gamePane1.SetActive(false);
        ��ʼ����.Instance.menuPane1.SetActive(true);
    }
    void OnCloseButtonClick()
    {
        CloseUI();
    }
    void OpenUI()
    {
        dialogueBox.SetActive(true);
        bottomButtons.SetActive(true);
    }
    void CloseUI()
    {
        dialogueBox.SetActive(false);
        bottomButtons.SetActive(false);
    }
    #endregion
    #endregion
}
