using UnityEngine;
using UnityEngine.UI;

public class 初始界面 : MonoBehaviour
{
    public GameObject menuPane1;
    public Button startButton;
    public Button continueButton;
    public Button loadButton;
    public Button 画廊;
    public Button settingsButton;
    public Button quitButton;

    private bool hasStarted = false;
    public static 初始界面 Instance { get; private set;}
    private void Awake()
    {
        if(Instance== null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    void Start()
    {
        menuButtonsAddListener();
    }
    void menuButtonsAddListener()
    {
        startButton.onClick.AddListener(StartGame);
        continueButton.onClick.AddListener(ContinueGame);
        loadButton.onClick.AddListener(LoadGame);
        画廊.onClick.AddListener(Showhualang1);
        settingsButton.onClick.AddListener(ShowSettingPanel);
        quitButton.onClick.AddListener(QuitGame);
    }
    private void StartGame()
    {
        hasStarted = true;
        VNmang.Instance.StartGame();
        ShowGamePanel();
    }
    private void ContinueGame()
    {
        if (hasStarted)
        {
            ShowGamePanel();
        }
    }
    private void Showhualang1()
    {
        menuPane1.SetActive(false);
        画廊系统.Instance.Showhualang();
    }
    private void LoadGame()
    {
        VNmang.Instance.ShowLoadPane1(ShowGamePanel);
    }
    private void ShowGamePanel()
    {
        menuPane1.SetActive(false);
        VNmang.Instance.gamePane1.SetActive(true);
    }
    private void ShowSettingPanel()
    {
        设置.Instance.显示设置();
    }
    private void QuitGame()
    {
        Application.Quit();
    }

}
