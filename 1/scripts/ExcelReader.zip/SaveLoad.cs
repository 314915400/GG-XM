using Newtonsoft.Json;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SaveLoad : MonoBehaviour
{
    public GameObject saveLoadPane1;
    public TextMeshProUGUI panelTitle;
    public Button[] saveLoadButtons;
    public Button prevPageButton;
    public Button nextPageButton;
    public Button bakeButton;

    private bool isSave;
    private int currentPage = Constants.DEFAULT_START_INDEX;
    private readonly int slotsPerPage = Constants.SLOTS_PER_PAGE;
    private readonly int totalSlots = Constants.TOTAL_SLOTS;
    private System.Action<int> currentAction;//һ��ί�����ͣ�����һ��int�����޷���ֵ�ķ�����
    private System.Action menuAction;

    public static SaveLoad Instance { get; private set; }
    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        prevPageButton.onClick.AddListener(PrevPage);
        nextPageButton.onClick.AddListener(NextPage);
        bakeButton.onClick.AddListener(GoBack);
        saveLoadPane1.SetActive(false);
    }
    public void ShowSavePane1(System.Action<int> action)//��ʾ�������
    {
        isSave = true;
        panelTitle.text = Constants.SAVE_GAME;//����
        currentAction = action;//����Ļص�����
        UpdateUI();//����UI
        saveLoadPane1.SetActive(true);//��ʾ����
    }
    public void ShowLoadPane1(System.Action<int> action,System.Action menuAction)//��ʾ���ؽ���
    {
        isSave = false;
        panelTitle.text = Constants.LOAD_GAME;
        currentAction = action;
        this.menuAction = menuAction;//showgamepanl
        UpdateUI();
        saveLoadPane1.SetActive(true);
    }
    private void UpdateUI()
    {
        for (int i = 0; i < slotsPerPage; i++)
        {
            int slotIndex = currentPage * slotsPerPage + i;//��ǰҳ������
            if (slotIndex < totalSlots)
            {
                UpdateSaveLoadButtons(saveLoadButtons[i], slotIndex);//���°�ť
                LoadStorylineAndScreenshots(saveLoadButtons[i], slotIndex);//���ع����߽�ͼ
            }
            else
            {
                saveLoadButtons[i].gameObject.SetActive(false);
            }
        }
    }
    private void UpdateSaveLoadButtons(Button button, int index)
    {
        button.gameObject.SetActive(true);//��ť��Ϊ�ɼ�
        button.interactable = true;//��ť��Ϊ�ɵ��

        var savePath = GenerateDataPath(index);//������������·��
        var fileExists = File.Exists(savePath);//�ж��ļ��Ƿ����

        if (!isSave && !fileExists)//����Ǽ��ز����ļ�������
        {
            button.interactable = false;//��ť��Ϊ���ɵ��
        }

        var textComponents = button.GetComponentsInChildren<TextMeshProUGUI>();//��ȡ�����
        textComponents[0].text = null;//����ı���������ʾ����
        textComponents[1].text = (index + 1) + Constants.COLON + Constants.EMPLY_SLOT;//������ʱ��
        button.GetComponentInChildren<RawImage>().texture = null;//Ŀǰû�н�ͼ

        button.onClick.RemoveAllListeners();//�Ƴ�������/�¼�
        button.onClick.AddListener(() => OnButtonClick(button, index));//�����µļ�����

    }
    private void OnButtonClick(Button button, int index)
    {
        //currentAction(index);//��ȷcurrentAction?.Invoke(index);
        menuAction?.Invoke();
        currentAction?.Invoke(index);
        if (isSave)
        {
            LoadStorylineAndScreenshots(button, index);
        }
        else
        {
            GoBack();
        }
    }
    private void PrevPage()
    {
        if (currentPage > 0)
        {
            currentPage--;
            UpdateUI();
        }
    }
    private void NextPage()
    {
        if ((currentPage + 1) * slotsPerPage < totalSlots)
        {
            currentPage++;
            UpdateUI();
        }
    }
    private void GoBack()
    {
        saveLoadPane1.SetActive(false);
    }
    private void LoadStorylineAndScreenshots(Button button, int index)
    {
        var savePath = GenerateDataPath(index);//������������·��
        if(File.Exists(savePath))//����д浵
        {
            string json = File.ReadAllText(savePath);
            var saveData = JsonConvert.DeserializeObject<VNmang.SaveData>(json);//�����л�
            if (saveData.savedScreenshotData != null)
            {
                Texture2D screenshot = new Texture2D(2,2);
                screenshot.LoadImage(saveData.savedScreenshotData);//����ͼƬ
                button.GetComponentInChildren<RawImage>().texture = screenshot;//����ͼƬ����Ϊ��ͼ
            }
            if (saveData.savedSpeakingContent != null)
            {
                var textComponents = button.GetComponentsInChildren<TextMeshProUGUI>();
                textComponents[0].text = saveData.savedSpeakingContent;
                textComponents[1].text = File.GetLastWriteTime(savePath).ToString("G");
            }
        }
    }

    private string GenerateDataPath(int index)
    {
        return Path.Combine(Application.persistentDataPath, Constants.SAVE_FILE_PATH , index + Constants.SAVE_FILE_EXTENSION);
    }

}
