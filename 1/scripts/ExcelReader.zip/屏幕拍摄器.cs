using UnityEngine;

public class 屏幕拍摄器 : MonoBehaviour
{
    public Texture2D CaptureScreenshot()//捕获著摄像机的内容，返回一个缩小的截图
    {
        int width = Screen.width;
        int height = Screen.height;

        RenderTexture rt =RenderTexture.GetTemporary(width,height,24);

        Camera mainCamera = Camera.main;//获取主摄像机

        if(mainCamera ==null)
        {
            Debug.LogError(Constants.CAMERA_NOT_FOUND);
            return null;
        }
        //设置渲染目标
        mainCamera.targetTexture = rt;//设置渲染结果为rt
        RenderTexture.active = rt;//设置渲染目标为rt
        mainCamera.Render();//渲染

        Texture2D screenshot = new Texture2D(width,height,TextureFormat.RGB24,false);//一个型对象
        screenshot.ReadPixels(new Rect(0, 0, width, height), 0, 0);//读取数据到screenshot    
        screenshot.Apply();//应用更改

        mainCamera.targetTexture = null;//著摄像机目标为屏幕
        RenderTexture.active = null;//清楚渲染目标
        RenderTexture.ReleaseTemporary(rt);//释放临时渲染目标

        Texture2D resizedScreenshot = ResizeTexture(screenshot, width / 6, height / 6);//缩小截图

        Destroy(screenshot);//销毁截图

        return resizedScreenshot;
    }
    public Texture2D ResizeTexture(Texture2D original, int newWidth, int newHeight)//缩小纹理
    {
        RenderTexture rt = RenderTexture.GetTemporary(newWidth, newHeight,24);
        RenderTexture.active = rt;

        Graphics.Blit(original, rt);

        Texture2D resized = new Texture2D(newWidth, newHeight, TextureFormat.RGB24, false);
        resized.ReadPixels(new Rect(0, 0, newWidth, newHeight), 0, 0);
        resized.Apply();

        RenderTexture.active = null;
        RenderTexture.ReleaseTemporary(rt);

        return resized;
    }
}
